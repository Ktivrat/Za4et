from django.db import models

# Create your models here.

class Breakfast(models.Model):
        name = models.CharField(max_length=50)
        calories = models.IntegerField()
        descript = models.TextField()
        ingredients = models.CharField(max_length=1000)
        img = models.ImageField()
        meat = models.CharField(max_length=50, default='zavtrak')
        
class Lunch(models.Model):
        name = models.CharField(max_length=50)
        calories = models.IntegerField()
        descript = models.TextField()
        ingredients = models.CharField(max_length=1000)
        img = models.ImageField()
        meat = models.CharField(max_length=50, default='obed')
        
class Dinner(models.Model):
        name = models.CharField(max_length=50)
        calories = models.IntegerField()
        descript = models.TextField()
        ingredients = models.CharField(max_length=1000)
        img = models.ImageField()
        meat = models.CharField(max_length=50, default='yjin')
        
