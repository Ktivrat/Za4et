from django.contrib import admin
from .models import *

# Register your models here.

@admin.register(Breakfast)
class BreakfastAdmin(admin.ModelAdmin):
    list_display = ('name','ingredients','calories','descript', 'img')
    
@admin.register(Lunch)
class LunchAdmin(admin.ModelAdmin):
    list_display = ('name','ingredients','calories','descript', 'img')
    
@admin.register(Dinner)
class DinnerAdmin(admin.ModelAdmin):
    list_display = ('name','ingredients','calories','descript', 'img')