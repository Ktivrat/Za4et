from django import forms

class RecipeSearchForm(forms.Form):
    search_query = forms.CharField(label='Поиск по рецептам', max_length=100)
