from django.shortcuts import render
from .models import *  
from django.http import HttpResponse
from django.db.models import Q # Q - это объект, предоставляемый в Django для создания сложных условий запроса

def main(request):
    return render(request, 'main.html')



def recip(request, id):
    id = int(id)
    data = {}
    search_query = request.POST.get('search_query', '')

    if id == 1:
        if search_query:
            items = Breakfast.objects.filter(Q(name__icontains=search_query) | Q(descript__icontains=search_query) | Q(ingredients__icontains=search_query))
        else:
            items = Breakfast.objects.all()
        zag = 'Завтраки'
        data = {'items': items, 'zag': zag}
        
    elif id == 2:
        if search_query:
            items = Lunch.objects.filter(Q(name__icontains=search_query) | Q(descript__icontains=search_query) | Q(ingredients__icontains=search_query))
        else:
            items = Lunch.objects.all()
        zag = 'Обеды'
        data = {'items': items, 'zag': zag}
        
    elif id == 3:
        if search_query:
            items = Dinner.objects.filter(Q(name__icontains=search_query) | Q(descript__icontains=search_query) | Q(ingredients__icontains=search_query))
        else:
            items = Dinner.objects.all()
        zag = 'Ужины'
        data = {'items': items, 'zag': zag}
   
    return render(request, 'recip.html', context=data)



def reciptheone(request, id, meat):
    id = int(id)
    if meat=='zavtrak':
        allrecipe = Breakfast.objects.get(id=id)
    elif meat=='obed':
        allrecipe = Lunch.objects.get(id=id)
    elif meat=='yjin':
        allrecipe = Dinner.objects.get(id=id)
        
    columb = allrecipe.ingredients.split('.')
    
    data = {'allrecipe': allrecipe, 'columb': columb}
    return render(request, 'reciptheone.html', context=data)
  
    
    
    

    


